# Vehicle Detection > 2023-12-05 4:37pm
https://universe.roboflow.com/stop-sign-camera/vehicle-detection-vda33

Provided by a Roboflow user
License: MIT

