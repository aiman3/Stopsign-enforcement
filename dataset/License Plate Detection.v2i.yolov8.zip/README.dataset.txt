# License Plate Detection > 2023-11-29 10:20pm
https://universe.roboflow.com/umass-lowell-dapvm/license-plate-detection-blhfu

Provided by a Roboflow user
License: MIT

